package chairing.chairing.repository.delivery;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import chairing.chairing.domain.delivery.Delivery;


@Repository
public interface DeliveryRepository extends JpaRepository<Delivery, Long> {
    // 추가로 deliveryId로 배송을 찾는 메서드를 정의할 수 있습니다.
    Delivery findByDeliveryId(Long deliveryId);
}
