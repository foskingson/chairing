package chairing.chairing.service.delivery;

import chairing.chairing.domain.delivery.Delivery;
import chairing.chairing.domain.delivery.DeliveryStatus;
import chairing.chairing.repository.delivery.DeliveryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DeliveryService {

    private final DeliveryRepository deliveryRepository;

    public List<Delivery> getAllDeliveries() {
        return deliveryRepository.findAll();
    }

    public Delivery addDelivery(String name) {
        Delivery delivery = new Delivery();
        delivery.setName(name);
        delivery.setStatus(DeliveryStatus.valueOf("배송 준비"));
        return deliveryRepository.save(delivery);
    }

    public Delivery updateStatus(Long deliveryId, String status) {
        Delivery delivery = deliveryRepository.findById(deliveryId)
                .orElseThrow(() -> new IllegalArgumentException("배송 정보를 찾을 수 없습니다."));
        delivery.setStatus(DeliveryStatus.valueOf(status));
        return deliveryRepository.save(delivery);
    }
}
