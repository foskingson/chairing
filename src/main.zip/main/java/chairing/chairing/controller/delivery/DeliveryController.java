package chairing.chairing.controller.delivery;

import chairing.chairing.domain.delivery.Delivery;
import chairing.chairing.service.delivery.DeliveryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/delivery")
@RequiredArgsConstructor
public class DeliveryController {

    private final DeliveryService deliveryService;

    // 택배사 페이지 환영 메시지
    @GetMapping
    public ResponseEntity<String> deliveryPage() {
        return ResponseEntity.ok("Welcome to the delivery page");
    }

    @GetMapping("/deliveries")
    public ResponseEntity<List<Delivery>> getAllDeliveries() {
        return ResponseEntity.ok(deliveryService.getAllDeliveries());
    }

    @PostMapping("/deliveries")
    public ResponseEntity<Delivery> addDelivery(@RequestParam String name) {
        return ResponseEntity.ok(deliveryService.addDelivery(name));
    }

    @PutMapping("/deliveries/{deliveryId}")
    public ResponseEntity<Delivery> updateStatus(
            @PathVariable Long deliveryId, @RequestParam String status) {
        return ResponseEntity.ok(deliveryService.updateStatus(deliveryId, status));
    }
}
